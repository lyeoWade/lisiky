﻿(function(){
	window.addMyRadio=function(){
		var aInput=document.getElementsByTagName('input');
		var arr=[];
		for(var i=0;i<aInput.length;i++)
		{
			//addradio
			if(aInput[i].getAttribute('addradio'))
			{
				//addRadio(aInput[i].name);
				if(!findSame(arr,aInput[i].name))
				{
					arr.push(aInput[i].name);
					addRadio(aInput[i].name);
				}
				
			}	
		}

	};
	
	function findSame(_arr,str)
	{
		for(var i=0;i<_arr.length;i++)
		{
			if(str==_arr[i])
			{
				return true	
			}	
		}
		
		return false;
	};
	
	function addRadio(name)
	{
		var aSex=document.getElementsByName(name);
		var radioArr=[];
		
		for(var i=0;i<aSex.length;i++)
		{
			var newSpan=document.createElement('span');
			newSpan.className='radio_off';	
			aSex[i].parentNode.insertBefore(newSpan,aSex[i]);
			aSex[i].style.display='none';
			radioArr.push(newSpan);
			(function(index){
				newSpan.onclick=function()
				{
					for(var i=0;i<radioArr.length;i++)
					{
						radioArr[i].className='radio_off';
					};
					this.className='radio_on';
					aSex[index].checked=true;
				};
			})(i);
			
		};
		
		
		
	};
	
	var oLink=document.createElement('link');
	oLink.type='text/css';
	oLink.rel='stylesheet';
	oLink.href='myRadio.css';
	var head=document.getElementsByTagName('head')[0];
	head.appendChild(oLink);	
})();