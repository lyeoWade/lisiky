//版权 北京智能社©, 保留所有权利

(function (){
	b=12;
	
	alert(b);
})();