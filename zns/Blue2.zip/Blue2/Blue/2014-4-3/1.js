//版权 北京智能社©, 保留所有权利

'use strict';

(function (){
	a=5;
	
	alert(a);
})();