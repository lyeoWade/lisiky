//版权 北京智能社©, 保留所有权利

define(function (require, exports, module){
	var jsonp=require('../common/common.js').jsonp;
	var url=require('../common/config.js').API_URL;
	var cb=require('../common/config.js').CB_NAME;
	
	module.exports={
		reg:		function (user, pass, face, fnSucc)
		{
			//检查
			if(face<1 || face>8 || isNaN(face))
			{
				alert('注册失败——face有误');
				return;
			}
			
			//?a=reg&user=用户名&pass=密码&face=头像ID&cb=xxx
			jsonp(url, {
				a: 'reg',
				user: user,
				pass: pass,
				face: face
			}, cb, fnSucc);
		},
		lgn:		function (user, pass, fnSucc)
		{
			
		},
		logout:		function (token, fnSucc)
		{
		}
	};
});