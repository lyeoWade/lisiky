//版权 北京智能社©, 保留所有权利

define(function (require, exports, module){
	module.exports={
		API_URL:	'http://localhost/zns_im4/api.php',
		CB_NAME:	'cb'
	};
});