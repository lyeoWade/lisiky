//版权 北京智能社©, 保留所有权利

define(function (require, exports, module){
	module.exports={
		addReady:		function (fn)
		{
			//高级——
			if(document.addEventListener)
			{
				document.addEventListener('DOMContentLoaded', fn, false);
			}
			//IE6-8
			else
			{
				document.attachEvent('onreadystatechange', function (){
					if(document.readyState=='complete')
					{
						fn();
					}
				});
			}
		},
		getByClass:		function (oParent, sClass)
		{
			if(oParent.getElementsByClassName)
			{
				return oParent.getElementsByClassName(sClass);
			}
			else
			{
				var aEle=oParent.getElementsByTagName('*');
				var result=[];
				
				//var re=/\b/+sClass+/\b/;
				var re=new RegExp('\\b'+sClass+'\\b');
				
				for(var i=0;i<aEle.length;i++)
				{
					//if(aEle[i].className==sClass)
					if(re.test(aEle[i].className))
					{
						result.push(aEle[i]);
					}
				}
			}
			
			return result;
		},
		addEvent:		function (obj, sEv, fn)
		{
			if(obj.addEventListener)
			{
				obj.addEventListener(sEv, function (ev){
					if(false==fn.call(obj, ev))
					{
						ev.cancelBubble=true;
						
						ev.preventDefault();
					}
				}, false);
			}
			else
			{
				obj.attachEvent('on'+sEv, function (){
					if(false==fn.call(obj, event))
					{
						event.cancelBubble=true;
						
						return false;
					}
				});
			}
		},
		jsonp:			function (url, data, cbName, fn)
		{
			var fnName='jsonp'+Math.random();
			fnName=fnName.replace('.', '');
			
			window[fnName]=function ()
			{
				fn.apply(null, arguments);
				
				//清理
				oHead.removeChild(oS);
				window[fnName]=null;
			};
			
			data[cbName]=fnName;
			var arr=[];
			var sData='';
			
			for(var i in data)
			{
				arr.push(i+'='+encodeURIComponent(data[i]));
			}
			
			sData=arr.join('&');
			
			var oS=document.createElement('script');
			oS.src=url+'?'+sData;
			
			var oHead=document.getElementsByTagName('head')[0];
			oHead.appendChild(oS);
		}
	};
});