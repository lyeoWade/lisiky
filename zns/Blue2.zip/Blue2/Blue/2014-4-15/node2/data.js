//版权 北京智能社©, 保留所有权利

var querystring=require('querystring');

exports.getData=function (request, fnSucc)
{
	//1.GET数据
	var url='';
	var GET={};
	
	if(request.url.indexOf('?')!=-1)
	{
		var arr=request.url.split('?');
		
		url=arr[0];
		GET=querystring.parse(arr[1]);
	}
	else
	{
		url=request.url;
		GET={};
	}
	
	//2.POST数据
	var str='';
	var POST={};
	
	request.addListener('data', function (s){
		str+=s;
	});
	
	request.addListener('end', function (){
		POST=querystring.parse(str);
		
		fnSucc && fnSucc(url, GET, POST);
	});
};