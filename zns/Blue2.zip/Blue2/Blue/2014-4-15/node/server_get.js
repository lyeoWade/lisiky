//版权 北京智能社©, 保留所有权利

var http=require('http');
var fs=require('fs');

var httpObj=http.createServer(function (request, response){
	//console.log(request.url);
	
	var url='';		//地址
	var GET={};		//数据
	//'/user?user=blue&pass=123456'
	//'/favicon.ico'
	
	if(request.url.indexOf('?')!=-1)
	{
		var arr=request.url.split('?');
		//arr[0]		/user					文件名
		//arr[1]		user=blue&pass=123456	数据
		
		url=arr[0];
		
		var arr2=arr[1].split('&');
		//arr2=['user=blue', 'pass=123456']
		
		for(var i=0;i<arr2.length;i++)
		{
			var arr3=arr2[i].split('=');
			//arr3[0]	名字		user/pass
			//arr3[1]	值		blue/123456
			
			GET[arr3[0]]=decodeURIComponent(arr3[1]);
		}
	}
	else
	{
		url=request.url;
		GET={};
	}
	
	console.log(url, GET);
	
	response.end();
});

httpObj.listen(8080);