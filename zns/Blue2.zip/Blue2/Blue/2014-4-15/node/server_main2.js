//版权 北京智能社©, 保留所有权利

var http=require('http');
var fs=require('fs');
var querystring=require('querystring');

var httpObj=http.createServer(function (request, response){
	//1.GET数据
	var url='';
	var GET={};
	
	if(request.url.indexOf('?')!=-1)
	{
		var arr=request.url.split('?');
		
		url=arr[0];
		GET=querystyring.parse(arr[1]);
	}
	else
	{
		url=request.url;
		GET={};
	}
	
	//2.POST数据
	var str='';
	var POST={};
	
	request.addListener('data', function (s){
		str+=s;
	});
	
	request.addListener('end', function (){
		POST=querystring.parse(str);
		
		//3.文件
		var fName='www'+url;
		
		fs.readFile(fName, function (err, data){
			if(err)
			{
				response.write('404');
			}
			else
			{
				response.write(data);
			}
			
			response.end();
		});
	});
	
	
});

httpObj.listen(8080);