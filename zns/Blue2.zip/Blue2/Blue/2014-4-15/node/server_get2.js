//版权 北京智能社©, 保留所有权利

var http=require('http');
var fs=require('fs');
var querystring=require('querystring');

var httpObj=http.createServer(function (request, response){
	var url='';		//地址
	var GET={};		//数据
	
	if(request.url.indexOf('?')!=-1)
	{
		var arr=request.url.split('?');
		
		url=arr[0];
		GET=querystring.parse(arr[1]);
	}
	else
	{
		url=request.url;
		GET={};
	}
	
	console.log(url, GET);
	
	response.end();
});

httpObj.listen(8080);