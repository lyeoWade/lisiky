//版权 北京智能社©, 保留所有权利

var http=require('http');
var fs=require('fs');
var querystring=require('querystring');

var dbMod=require('./db.js');

var httpObj=http.createServer(function (request, response){
	//1.GET数据
	var url='';
	var GET={};
	
	if(request.url.indexOf('?')!=-1)
	{
		var arr=request.url.split('?');
		
		url=arr[0];
		GET=querystring.parse(arr[1]);
	}
	else
	{
		url=request.url;
		GET={};
	}
	
	//2.POST数据
	var str='';
	var POST={};
	
	request.addListener('data', function (s){
		str+=s;
	});
	
	request.addListener('end', function (){
		POST=querystring.parse(str);
		
		if(url=='/user')
		{
			//接口请求
			switch(GET.act)
			{
				case 'reg':
					var db=dbMod.create();
					
					db.query("SELECT * FROM user_table WHERE username='"+GET.user+"'", function (err, data){
						if(err)
						{
							response.write('{err: 1, msg: "数据库出错"}');
							response.end();
						}
						else
						{
							if(data.length>0)
							{
								response.write('{err: 1, msg: "此用户名已存在"}');
								response.end();
							}
							else
							{
								db.query("INSERT INTO user_table VALUES('"+GET.user+"', '"+GET.pass+"')", function (err, data){
									if(err)
									{
										response.write('{err: 1, msg: "数据库出错"}');
										response.end();
									}
									else
									{
										response.write('{err: 0, msg: "注册成功"}');
										response.end();
									}
								});
							}
						}
					});
					break;
				case 'login':
					var db=dbMod.create();
					
					db.query("SELECT * FROM user_table WHERE username='"+GET.user+"'", function (err, data){
						if(err)
						{
							response.write('{err: 1, msg: "数据库出错"}');
							response.end();
						}
						else
						{
							if(data.length==0)
							{
								response.write('{err: 1, msg: "用户名不存在"}');
								response.end();
							}
							else
							{
								if(data[0].password==GET.pass)
								{
									response.write('{err: 0, msg: "登录成功"}');
									response.end();
								}
								else
								{
									response.write('{err: 1, msg: "密码错误"}');
									response.end();
								}
							}
						}
					});
					break;
			}
		}
		else
		{
			//3.文件
			var fName='www'+url;
			
			fs.readFile(fName, function (err, data){
				if(err)
				{
					response.write('404');
				}
				else
				{
					response.write(data);
				}
				
				response.end();
			});
		}
	});
	
	
});

httpObj.listen(8080);