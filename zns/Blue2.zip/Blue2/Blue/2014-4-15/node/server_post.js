//版权 北京智能社©, 保留所有权利

var http=require('http');
var fs=require('fs');
var querystring=require('querystring');

var httpObj=http.createServer(function (request, response){
	var str='';
	var POST={};
	
	//data事件——有数据到达了
	request.addListener('data', function (s){
		str+=s;
	});
	
	//end事件——数据全部到达
	request.addListener('end', function (){
		POST=querystring.parse(str);
		
		console.log(POST);
	});
	
	response.end();
});

httpObj.listen(8080);