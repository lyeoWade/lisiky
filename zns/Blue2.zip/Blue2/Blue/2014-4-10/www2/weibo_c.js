//版权 北京智能社©, 保留所有权利

define(function (require, exports, module){
	var modM=require('weibo_m.js');
	var modV=require('weibo_v.js');
	
	module.exports={
		sendMsg:	function (btnId, txtId)
		{
			var oBtn=document.getElementById(btnId);
			var oTxt=document.getElementById(txtId);
			
			oBtn.onclick=function ()
			{
				modM.add(oTxt.value, function (json){
					modV.addItem(oTxt.value, json.time, 0, 0);
				});
			};
		}
	};
});