//版权 北京智能社©, 保留所有权利

define(function (require, exports, module){
	var dumpEle=require('common.js').dumpEle;
	
	var oTmpReply=document.getElementById('tmp_reply');
	var oDiv=document.getElementById('msg_list');
	
	oDiv.removeChild(oTmpReply);
	
	module.exports={
		addItem:	function (content, time, acc, ref)
		{
			var oDate=new Date();
			
			oDate.setTime(time*1000);
			
			var sDate=oDate.getFullYear()+'-'+(oDate.getMonth()+1)+'-'+oDate.getDate()+' '+oDate.getHours()+':'+oDate.getMinutes();
			
			var oNewReply=dumpEle(oTmpReply, {
				content:	content,
				time:		sDate,
				acc:		acc,
				ref:		ref
			});
			
			//oDiv.appendChild(oNewReply);
			if(oDiv.children.length)
			{
				oDiv.insertBefore(oNewReply, oDiv.children[0]);
			}
			else
			{
				oDiv.appendChild(oNewReply);
			}
			
			/*oNewDiv.className='reply';
			oNewDiv.innerHTML=
				'<p class="replyContent">卫士，新款卫士将推出总共14种车身式样。其中， XS旅行款车型售价为32295英镑(约33.6万元)。</p>'+
                '<p class="operation">'+
                    <span class="replyTime">2011-09-08 16:37:60</span>
                    <span class="handle">
                    	<a href="javascript:;" class="top">0</a>
                        <a href="javascript:;" class="down_icon">0</a>
                        <a href="javascript:;" class="cut">删除</a>
                    </span>
                </p>';*/
		}
	};
});