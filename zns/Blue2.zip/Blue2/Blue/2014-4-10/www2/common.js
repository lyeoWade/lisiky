//版权 北京智能社©, 保留所有权利

define(function (require, exports, module){
	exports.dumpEle=function (obj, data)
	{
		var oTmp=document.createElement('div');
		
		oTmp.innerHTML=obj.outerHTML.replace(/\{\$\w+\}/g, function (s){
			s=s.substring(2, s.length-1);
			
			return data[s];
		});
		
		oTmp.children[0].id='';
		
		return oTmp.children[0];
	};
});