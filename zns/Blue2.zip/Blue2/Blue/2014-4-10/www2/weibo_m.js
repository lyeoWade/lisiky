//版权 北京智能社©, 保留所有权利

define(function (require, exports, module){
	var modAjax=require('ajax.js');
	var ajax=modAjax.ajax;
	
	module.exports={
		add:		function (content, fn)
		{
			ajax(
				'weibo.php?act=add&content='+content,
				function (str){
					var json=eval('('+str+')');
					
					fn && fn(json);
				},
				function (){}
			);
		}
	};
});