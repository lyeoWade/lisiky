//版权 北京智能社©, 保留所有权利

//取数据
function readFromBaidu(str, fn)
{
	//http://suggestion.baidu.com/su?wd=a&cb=xxx
	jsonp('http://suggestion.baidu.com/su', {
		wd:		str
	}, 'cb', function (json){
		fn(json.s);
	});
}

function jsonp(url, data, cbName, fn)
{
	var fnName='jsonp'+Math.random();
	fnName=fnName.replace('.', '');
	
	window[fnName]=function ()
	{
		fn.apply(null, arguments);
		
		//清理
		oHead.removeChild(oS);
		window[fnName]=null;
	};
	
	data[cbName]=fnName;
	var arr=[];
	var sData='';
	
	for(var i in data)
	{
		arr.push(i+'='+encodeURIComponent(data[i]));
	}
	
	sData=arr.join('&');
	
	var oS=document.createElement('script');
	oS.src=url+'?'+sData;
	
	var oHead=document.getElementsByTagName('head')[0];
	oHead.appendChild(oS);
}











