//版权 北京智能社©, 保留所有权利

define(function (require, exports, module){
	//require	请求另一个模块
	//exports	输出
	//module	批量输出
	
	var mod=require('b.js');
	
	exports.show=function ()
	{
		alert(mod.num1+mod.num2);
	};
});