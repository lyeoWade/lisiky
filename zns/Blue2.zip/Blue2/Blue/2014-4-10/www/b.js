//版权 北京智能社©, 保留所有权利

define(function (require, exports, module){
	var num1 = 5;
	exports(num1);
	exports.num2=10;
});