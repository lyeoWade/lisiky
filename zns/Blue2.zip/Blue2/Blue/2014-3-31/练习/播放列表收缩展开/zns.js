/*
智能社© - http://www.zhinengshe.com/

微博：@北京智能社
微信：zhi_neng_she

最具深度的前端开发培训机构 HTML+CSS/JS/HTML5
*/


window.onload=function ()
{
	var oDiv=document.getElementById('drop');
	var oH2=oDiv.getElementsByTagName('h2')[0];
	var oUl=oDiv.getElementsByTagName('ul')[0];
	
	oH2.onclick=showHideUl;
}

function showHideUl()
{
	var oDiv=document.getElementById('drop');
	var oUl=oDiv.getElementsByTagName('ul')[0];
	
	if(oUl.style.display === 'none')
	{
		oUl.style.display='block';
	}
	else
	{
		oUl.style.display='none';
	}
}