//版权 北京智能社©, 保留所有权利

function jsonp(options)
{
	options=options||{};
	options.data=options.data||{};
	options.cbName=options.cbName||'cb';
	
	//1.名字
	var fnName='jsonp_'+Math.random();
	fnName=fnName.replace('.', '');
	
	//2.回调函数
	window[fnName]=function (json)
	{
		options.succ && options.succ(json);
		
		//清理
		oHead.removeChild(oS);
		window[fnName]=null;
		
		clearTimeout(timer);
	};
	
	//3.数据拼url
	options.data[options.cbName]=fnName;
	
	var arr=[];
	
	for(var i in options.data)
	{
		arr.push(i+'='+encodeURIComponent(options.data[i]));
	}
	
	var sData=arr.join('&');
	
	//4.创建script
	var oS=document.createElement('script');
	
	oS.src=options.url+'?'+sData;
	
	var oHead=document.getElementsByTagName('head')[0];
	
	oHead.appendChild(oS);
	
	//5.超时
	if(options.timeout)
	{
		var timer=setTimeout(function (){
			options.error && options.error();
			
			oHead.removeChild(oS);
			window[fnName]=null;
		}, options.timeout);
	}
}