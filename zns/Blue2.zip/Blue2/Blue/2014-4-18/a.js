//版权 北京智能社©, 保留所有权利

define(function (require, exports, module){
	module.exports={
		//在页面加载完之后调用
		addReady:		function (fn)
		{
			if(bReady==false)
			{
				//加载前
				document.addEventListener('DOMContentLoaded', fn, false);
			}
			else
			{
				//加载后
				fn();
			}
		}
	};
});