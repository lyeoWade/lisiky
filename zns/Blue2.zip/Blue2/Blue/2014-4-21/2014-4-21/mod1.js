//版权 北京智能社©, 保留所有权利

define(function (require, exports, module){
	var modA=require('a.js');
	
	exports.add=function ()
	{
		modA.a+=5;
	};
});