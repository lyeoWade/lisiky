//版权 北京智能社©, 保留所有权利

function getStyle(obj, name)
{
	return obj.currentStyle?obj.currentStyle[name]:getComputedStyle(obj, false)[name];
}

function startMove(obj, json, fnEnd)
{
	clearInterval(obj.timer);
	obj.timer=setInterval(function (){
		var end=true;
		for(var name in json)
		{
			var cur=parseInt(getStyle(obj, name));
			
			var speed=(json[name]-cur)/8;
			speed=speed>0?Math.ceil(speed):Math.floor(speed);
			
			obj.style[name]=cur+speed+'px';
			
			if(cur!=json[name])
			{
				end=false;
			}
		}
		
		if(end)
		{
			clearInterval(obj.timer);
			fnEnd && fnEnd();
		}
	}, 30);
}







