//版权 北京智能社©, 保留所有权利

(function (){
	var json={
		email:		/^[\.\w]+@([a-z0-9][a-z0-9\-]{0,61}[a-z0-9]|[a-z0-9])(\.[a-z]{2,4}){1,2}$/i,
		username:	/^[a-z0-9]\w{7,63}$/i,
		age:		/^(1[6-9]|[2-9]\d|100)$/,
		person_id:	/^[1-9]\d{16}[\dx]$/i,
		addr:		/^([\u4e00-\u9fa5]{2,7}省)?\s*[\u4e00-\u9fa5]+市$/,
		url:		/^(https?:\/\/)?([a-z0-9\-]+\.)+[a-z]{2,4}(\.[a-z]{2,4})?\/?$/i,
		pass:		/^.{6,}$/,
		pass2:		/^.{6,}$/
	};
	
	window.formCheck=function (id, fn)
	{
		var oForm=document.getElementById(id);
		
		var aInput=oForm.getElementsByTagName('input');
		
		for(var i=0;i<aInput.length;i++)
		{
			var re=json[aInput[i].name];
			
			if(re)
			{
				(function (re){
					aInput[i].onblur=function ()
					{
						check(this, re);
					};
				})(re);
			}
		}
		
		function check(oTxt, re)
		{
			//第一关
			if(re.test(oTxt.value))
			{
				//第二关、二次校验
				if(!fn)	//不需要二次校验
				{
					oTxt.className='ok';
					return true;
				}
				else
				{
					if(false==fn(oTxt))
					{
						oTxt.className='error';
						return false;
					}
					else
					{
						oTxt.className='ok';
						return true;
					}
				}
			}
			else
			{
				oTxt.className='error';
				return false;
			}
		}
		
		oForm.onsubmit=function ()
		{
			var ok=true;
			for(var i=0;i<aInput.length;i++)
			{
				var re=json[aInput[i].name];
				
				if(re)
				{
					if(check(aInput[i], re)==false)
					{
						ok=false;
					}
				}
			}
			
			if(ok==false)
			{
				return false;
			}
			/*if(false==check(oUsername, reUsername))
			{
				return false;
			}
			
			if(false==check(oEmail, reEmail))
			{
				return false;
			}*/
		};
	}
})();