//版权 北京智能社©, 保留所有权利

var fs=require('fs');

//fs->file system

//readFile('文件名', 回调函数);
fs.readFile('1.js', function (err, data){
	//console.log(err);
	
	if(err)
	{
		console.log('读取出错');
	}
	else
	{
		console.log('读取成功'+data);
	}
});