//版权 北京智能社©, 保留所有权利

var http=require('http');
var fs=require('fs');

var httpObj=http.createServer(function (request, response){
	//request.url
	//http://localhost:8080/a.html	"/a.html"	"www/a.html"
	//"/aaa/b.html"		"www/aaa/b.html"
	
	var fName='www'+request.url;
	
	fs.readFile(fName, function (err, data){
		if(err)
		{
			response.write('404');
			console.log(request.url+'失败');
		}
		else
		{
			response.write(data);
			console.log(request.url+'成功');
		}
		
		response.end();
	});
});

//监听——等着
httpObj.listen(8080);











