//版权 北京智能社©, 保留所有权利

var str='dfas 342 dfs 45345 4353 dgdf';

console.log(str.match(/\d+/g));