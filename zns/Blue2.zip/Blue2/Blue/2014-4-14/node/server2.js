//版权 北京智能社©, 保留所有权利

var http=require('http');

var httpObj=http.createServer(function (request, response){	//回调函数
	//有人来访问
	//request		请求		被请求——输入
	//response		响应		主动——输出
	
	response.write('<html><head><title>标题</title></head><body><div style="width:200px; height:200px; background: red;"></div></body></html>');
	response.end();
	
	console.log('有人来了');
});

//监听——等着
httpObj.listen(8080);











