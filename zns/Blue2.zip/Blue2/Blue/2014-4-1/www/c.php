<?php
sleep(3);

echo $_POST['a']+$_POST['b'];
?>