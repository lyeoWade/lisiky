//版权 北京智能社©, 保留所有权利

$.fn.accordion=function (){
	this.each(function (index, element){
		$(element).find('h2').click(function (){
			var oUl=$(this).next();
			
			if($(this).hasClass('active'))
			{
				$(this).removeClass('active');
				oUl.stop().animate({height: 0});
			}
			else
			{
				var aLi=oUl.find('li');
				
				$(element).find('h2').removeClass('active');
				$(element).find('ul').stop().animate({height: 0});
				
				$(this).addClass('active');
				oUl.stop().animate({
					//height:	aLi.eq(0).outerHeight()*aLi.length
					height:	aLi[0].offsetHeight*aLi.length+'px'
				});
			}
		});
		
		$(element).find('h2').mousedown(function (){
			return false;
		});
	});
}