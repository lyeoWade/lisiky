//版权 北京智能社©, 保留所有权利

(function (){
	var form_reg={
		email:		/^([a-z0-9][\w\.]*@[a-z0-9\-]+(\.[a-z]{2,4}){1,2})$/,
		cn_name:	/^([\u4e00-\u9fa5]{2,8})$/,
		zip_code:	/^([1-9]\d{5})$/,
		pass:		/^(.{4,32})$/,
		pass2:		/^(.{4,32})$/
	};
	
	window.formCheck=function (id, fnCheck)
	{
		var oForm=document.getElementById(id);
		var aInput=oForm.getElementsByTagName('input');
		
		function check(oTxt, re)
		{
			//第一关
			if(re.test(oTxt.value))
			{
				//第二关
				if(!fnCheck)
				{
					oTxt.className='ok';
					return true;
				}
				else
				{
					if(fnCheck(oTxt))
					{
						oTxt.className='ok';
						return true;
					}
					else
					{
						oTxt.className='error';
						return false;
					}
				}
			}
			else
			{
				oTxt.className='error';
				return false;
			}
		}
		
		//失去焦点
		for(var i=0;i<aInput.length;i++)
		{
			if(form_reg[aInput[i].name])
			{
				(function (index){
					aInput[i].onblur=function ()
					{
						check(this, form_reg[aInput[index].name]);
					};
				})(i);
			}
		}
		
		//提交
		oForm.onsubmit=function ()
		{
			var ok=true;
			
			for(var i=0;i<aInput.length;i++)
			{
				if(form_reg[aInput[i].name])
				{
					if(false==check(aInput[i], form_reg[aInput[i].name]))
					{
						ok=false;
					}
				}
			}
			
			if(!ok)
			{
				return false;
			}
		};
	};
	
	document.write('<link rel="stylesheet" type="text/css" href="formCheck.css" />');
})();