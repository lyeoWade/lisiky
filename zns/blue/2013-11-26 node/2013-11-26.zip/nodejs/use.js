//版权 北京智能社©, 保留所有权利

var modA=require('./a.js');

modA.show();