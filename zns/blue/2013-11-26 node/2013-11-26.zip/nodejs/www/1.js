//版权 北京智能社©, 保留所有权利

window.onload=function ()
{
	document.getElementsByTagName('h1')[0].onclick=function ()
	{
		alert('abc');
	};
};