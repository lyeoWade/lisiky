//版权 北京智能社©, 保留所有权利

exports.a=12;
exports.show=function ()
{
	console.log('abc');
};