//版权 北京智能社©, 保留所有权利

//定义模块
define(function (require, exports, module){
	/*
	require		请求
	exports		导出
	module		模块
	*/
	
	//alert(exports==module.exports);
	
	//exports只能一个个加
	//只有导出的东西，外面才能用
	/*exports.show=function ()
	{
		alert('abc');
	};
	
	exports.a=12;*/
	
	//module——批量导出
	/*module.exports={
		a: 12,
		b: 5
	};*/
	
	/*
	module.exports.a=12;
	module.exports.b=5;
	*/
	
	//写模块的东西
});