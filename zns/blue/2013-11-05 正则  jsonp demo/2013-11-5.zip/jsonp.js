//版权 北京智能社©, 保留所有权利
function json2url(json)
{
	var arr=[];
	
	for(var i in json)
	{
		arr.push(i+'='+json[i]);
	}
	
	return arr.join('&');
}

function jsonp(url, data, fnSucc)
{
	var fnName='jsonp_'+Math.random();
	fnName=fnName.replace('.', '');
	
	data.cb=fnName;
	
	window[fnName]=function (json)
	{
		fnSucc && fnSucc(json);
		
		oHead.removeChild(oS);
	};
	
	var str=url+'?'+json2url(data);
	
	var oS=document.createElement('script');
	
	oS.src=str;
	
	var oHead=document.getElementsByTagName('head')[0];
	oHead.appendChild(oS);
}