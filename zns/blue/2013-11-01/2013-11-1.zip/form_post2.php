<!DOCTYPE HTML>
<html>
<head>
<meta charset="utf-8">
<meta name="author" content="智能社 - zhinengshe.com" />
<meta name="copyright" content="智能社 - zhinengshe.com" />
<title>智能社 - www.zhinengshe.com</title>
<style>

</style>
</head>

<body>
<?php
echo $_POST['user'].'|'.$_POST['pass'];
?>
</body>
</html>












