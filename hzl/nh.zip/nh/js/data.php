<?php
	

	echo '[
		{"id":"1","num":"5","title":"大山黑猪肉","price":"22","coverpic":"images/hzl_1.png","unit":"斤","imageList":[{"pic":"images/1.jpg","pictitle":"当然也可以不需要一个对象，而是捕获添加时input的值，但这不是angular的写法，这是jQuery的写法。","picid":"1"},{"pic":"images/2.jpg","pictitle":"222","picid":"2"},{"pic":"images/3.jpeg","pictitle":"因为要生成不确定数量和内容的HTML元素，所以需要一个（双向绑定的）集合来保存它们；因为要生成不确定数量和内容的HTML元素，所以需要一个（双向绑定的）集合来保存它们；","picid":"3"},{"pic":"images/4.jpg","pictitle":"999999","picid":"4"}]},
		{"id":"2","num":"3","title":"大山纯良土鸡","price":"36","coverpic":"images/hzl_2.png","unit":"只","imageList":[{"pic":"images/1.jpg","pictitle":"11111","picid":"1"},{"pic":"images/3.jpeg","pictitle":"222","picid":"2"},{"pic":"images/4.jpg","pictitle":"33333","picid":"3"},{"pic":"images/4.jpg","pictitle":"因为要生成不确定数量和内容的HTML元素，所以需要一个（双向绑定的）集合来保存它们；因为要生成不确定数量和内容的HTML元素，所以需要一个（双向绑定的）集合来保存它们；","picid":"4"}]},
		{"id":"3","num":"0","title":"农家放养山羊农家放养山羊农家放养山羊","price":"30","coverpic":"images/hzl_09.png","unit":"斤"},
		{"id":"4","num":"0","title":"深山大黄牛","price":"35","coverpic":"images/hzl_10.png","unit":"斤"},
		{"id":"5","num":"0","title":"大山黑猪肉排骨","price":"30","coverpic":"images/hzl_13.png","unit":"斤"},
		{"id":"6","num":"0","title":"纯良土鸡蛋","price":"30","coverpic":"images/hzl_14.png","unit":"盒"},
		{"id":"7","num":"0","title":"深水库草鱼","price":"20","coverpic":"images/hzl_17.png","unit":"条"},
		{"id":"8","num":"0","title":"深水库鲫鱼","price":"25","coverpic":"images/hzl_18.png","unit":"条"},
		{"id":"9","num":"0","title":"深水库鲤鱼","price":"10","coverpic":"images/hzl_03.png","unit":"条"},
		{"id":"10","num":"0","title":"农家花生油","price":"50","coverpic":"images/hzl_22.png","unit":"斤"},
		{"id":"11","num":"0","title":"农家菜籽油","price":"40","coverpic":"images/hzl_25.png","unit":"斤"},
		{"id":"12","num":"0","title":"农家自榨香油","price":"30","coverpic":"images/hzl_26.png","unit":"斤"}
	]';

?>