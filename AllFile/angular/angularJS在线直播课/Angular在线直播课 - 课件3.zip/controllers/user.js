angular.module('userMod', [])
.controller('userController', function ($scope){
	$scope.name='blue';
	$scope.regtime=1473590054696;
});